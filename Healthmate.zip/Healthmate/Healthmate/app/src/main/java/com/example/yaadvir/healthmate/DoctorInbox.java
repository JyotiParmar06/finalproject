package com.example.yaadvir.healthmate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class DoctorInbox extends AppCompatActivity {


    TableLayout tblayout;
    TableRow tr1;
    TextView Firstname,Content;
    int uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_inbox);
        tblayout = findViewById(R.id.tablayout2);
        Toast.makeText(getApplicationContext(), "PLEASE SELECT THE NAME OF USER TO SEND THE MESSAGE", Toast.LENGTH_LONG).show();

        new MyTask().execute();
    }

    private class MyTask extends AsyncTask<Void, Void, Void> {



        @SuppressLint("WrongThread")
        @Override

        protected Void doInBackground(Void... params) {



            URL url = null;

            User_id userID=User_id.getInstance();

            uid=userID.getId();
            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/inbox&"+uid);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                final StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());
                final JSONObject obj = new JSONObject(response.toString());

                final JSONArray postarray = obj.getJSONArray("List");
                runOnUiThread(new Runnable() {
                    @SuppressLint("ResourceAsColor")
                    @Override
                    public void run() {

                        tblayout = findViewById(R.id.tablayout2);

                        tr1 = new TableRow(getApplicationContext());



                        Firstname = new TextView(getApplicationContext());
                        Firstname.setText(" FirstName ");
                        Firstname.setAlpha(1);
                        Firstname.setTextSize(10);
                        Firstname.setTextColor(Color.BLACK);

                        tr1.addView(Firstname);



                        Content = new TextView(getApplicationContext());
                        Content.setText(" CONTENT ");
                        Content.setAlpha(1);
                        Content.setTextSize(10);
                        Content.setTextColor(Color.BLACK);



                        tr1.addView(Content);

                        tblayout.addView(tr1);


                        String  firstname = null, content = null;



                        JSONObject arrayobj = null;

                        for (int i = 0; i < postarray.length(); i++) {
                            tr1 = new TableRow(getApplicationContext());


                            Firstname = new TextView(getApplicationContext());
                            Content = new TextView(getApplicationContext());




                            try {
                                arrayobj = postarray.getJSONObject(i);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            try {




                                Firstname.setTextSize(10);
                                Firstname.setAlpha(1);
                                Content.setTextSize(10);
                                Content.setAlpha(0.99f);

                                firstname = arrayobj.getString("FirstName");
                                Firstname.setText(firstname + "  ");
                                tr1.addView(Firstname);
                                content = arrayobj.getString("CONTENT");
                                Content.setText(content + "  ");
                                tr1.addView(Content);



                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                            tr1.setAlpha(1);


                            tblayout.addView(tr1);



                            final String finalFirstname = firstname;
                            tr1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent bridge = new Intent(getApplicationContext(), SendMessage.class);
                                    bridge.putExtra("Firstname", finalFirstname);
                                    startActivity(bridge);
                                }
                            });

                        }

                    }
                });
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }


    }

}

