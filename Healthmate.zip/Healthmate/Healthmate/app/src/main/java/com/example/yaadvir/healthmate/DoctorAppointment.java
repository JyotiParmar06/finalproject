package com.example.yaadvir.healthmate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class DoctorAppointment extends AppCompatActivity {


    TableLayout tblayout;
    TableRow tr1;
    TextView Fname,Lname,Time,date,Appid,pid;
    int uid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_appointment);
        Toast.makeText(getApplicationContext(), "PLEASE SELECT THE APPOINTMENT ID TO UPDATE HEALTH SUMMARY OF PATIENT", Toast.LENGTH_LONG).show();


        new MyTask().execute();
    }

    private class MyTask extends AsyncTask<Void, Void, Void> {



        @SuppressLint("WrongThread")
        @Override

        protected Void doInBackground(Void... params) {



            URL url = null;


            User_id userID=User_id.getInstance();

            uid=userID.getId();
            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/DoctorAppointment&"+uid);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                final StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());
                final JSONObject obj = new JSONObject(response.toString());

                final JSONArray postarray = obj.getJSONArray("Appointments");
                runOnUiThread(new Runnable() {
                    @SuppressLint("ResourceAsColor")
                    @Override
                    public void run() {

                        tblayout = findViewById(R.id.tablayout1);
                        tr1=new TableRow(getApplicationContext());

                        pid = new TextView(getApplicationContext());
                        pid.setText(" PatientUser_id ");
                        pid.setTextSize(10);
                        pid.setAlpha(1);
                        pid.setTextColor(Color.BLACK);

                        tr1.addView(pid);


                        Fname = new TextView(getApplicationContext());
                        Fname.setText(" PatientFirstName ");
                        Fname.setTextSize(10);
                        Fname.setAlpha(1);
                        Fname.setTextColor(Color.BLACK);

                        tr1.addView(Fname);


                        Lname = new TextView(getApplicationContext());
                        Lname.setText(" PatientLastName ");
                        Lname.setAlpha(1);
                        Lname.setTextSize(10);
                        Lname.setTextColor(Color.BLACK);

                        tr1.addView(Lname);



                        Time = new TextView(getApplicationContext());
                        Time.setText(" Appointment_Time ");
                        Time.setAlpha(1);
                        Time.setTextSize(10);
                        Time.setTextColor(Color.BLACK);

                        tr1.addView(Time);


                        date = new TextView(getApplicationContext());
                        date.setText(" Appointment_Date ");
                        date.setAlpha(1);
                        date.setTextSize(10);
                        date.setTextColor(Color.BLACK);

                        tr1.addView(date);




                        Appid = new TextView(getApplicationContext());
                        Appid.setText(" Appointment_Id ");
                        Appid.setTextSize(10);
                        Appid.setAlpha(1);
                        Appid.setTextColor(Color.BLACK);

                        tr1.addView(Appid);


                        tblayout.addView(tr1);


                        String  fname = null, lname = null, Spec=null,time=null,Date=null;
                      int appid=0,PID=0;

                        JSONObject arrayobj = null;

                        for (int i = 0; i < postarray.length(); i++) {

                            tr1 = new TableRow(getApplicationContext());


                           pid= new TextView(getApplicationContext());

                            Fname = new TextView(getApplicationContext());
                            Lname = new TextView(getApplicationContext());
                            Time = new TextView(getApplicationContext());
                            date = new TextView(getApplicationContext());

                            Appid = new TextView(getApplicationContext());



                            try {
                                arrayobj = postarray.getJSONObject(i);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            try {

                                pid.setTextSize(10);
                                pid.setAlpha(1);
                                Fname.setTextSize(10);
                                Fname.setAlpha(0.99f);
                                Lname.setTextSize(10);
                                Lname.setAlpha(0.99f);

                                Time.setTextSize(10);
                                Time.setAlpha(0.99f);
                                date.setTextSize(10);
                                date.setAlpha(0.99f);
                                Appid.setTextSize(10);
                                Appid.setAlpha(1);

                                PID= arrayobj.getInt("PatientUser_id");
                                pid.setText(PID + "  ");
                                tr1.addView(pid);
                                fname = arrayobj.getString("PatientFirstName");
                                Fname.setText(fname + "  ");
                                tr1.addView(Fname);
                                lname = arrayobj.getString("PatientLastName");
                                Lname.setText(lname + "  ");
                                tr1.addView(Lname);
                                 time = arrayobj.getString("Appointment_Time");
                                Time.setText(time + "  ");
                                tr1.addView(Time);
                                Date = arrayobj.getString("Appointment_Date");
                                date.setText(Date + "  ");
                                tr1.addView(date);
                                appid= arrayobj.getInt("Appointment_Id");
                                Appid.setText(appid + "  ");
                                tr1.addView(Appid);



                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                            tr1.setAlpha(1);



                            tblayout.addView(tr1);



                            final int finalAppid = appid;
                            tr1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent bridge = new Intent(getApplicationContext(), UpdateHealthSummary.class);
                                    bridge.putExtra("Appointment_Id", finalAppid);
                                    startActivity(bridge);
                                }
                            });



                        }

                    }
                });
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }


    }

}

