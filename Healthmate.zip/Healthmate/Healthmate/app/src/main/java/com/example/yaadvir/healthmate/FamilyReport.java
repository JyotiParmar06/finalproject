package com.example.yaadvir.healthmate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class FamilyReport extends AppCompatActivity {


    TableLayout tblayout;
    TableRow tr1;
    TextView Userid,Firstname,Lastname,Relname;
    int uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_family_report);


        Toast.makeText(getApplicationContext(), "PLEASE SELECT FIRSTNAME OF THE FAMILY MEMBER TO SEE THE REPORTS", Toast.LENGTH_LONG).show();


        new MyTask().execute();
        }

    private class MyTask extends AsyncTask<Void, Void, Void> {



        @SuppressLint("WrongThread")
        @Override

        protected Void doInBackground(Void... params) {



            URL url = null;


            User_id userID=User_id.getInstance();

            uid=userID.getId();
            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/Familyreport&"+uid);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                final StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());
                final JSONObject obj = new JSONObject(response.toString());

                final JSONArray postarray = obj.getJSONArray("FamilyMember");
                runOnUiThread(new Runnable() {
                    @SuppressLint("ResourceAsColor")
                    @Override
                    public void run() {

                        tblayout = findViewById(R.id.tablayout4);

                        tr1 = new TableRow(getApplicationContext());

                        Userid = new TextView(getApplicationContext());
                        Userid.setText(" User_id ");
                        Userid.setTextSize(20);
                        Userid.setAlpha(1);
                        Userid.setTextColor(Color.BLACK);

                        tr1.addView(Userid);


                        Firstname = new TextView(getApplicationContext());
                        Firstname.setText(" Firstname ");
                        Firstname.setAlpha(1);
                        Firstname.setTextSize(10);
                        Firstname.setTextColor(Color.BLACK);

                        tr1.addView(Firstname);

                        Lastname = new TextView(getApplicationContext());
                        Lastname.setText(" Lastname ");
                        Lastname.setAlpha(1);
                        Lastname.setTextSize(10);
                        Lastname.setTextColor(Color.BLACK);



                        tr1.addView(Lastname);

                        Relname = new TextView(getApplicationContext());
                        Relname.setText(" NAMEOFRELATION ");
                        Relname.setAlpha(1);
                        Relname.setTextSize(10);
                        Relname.setTextColor(Color.BLACK);



                        tr1.addView(Relname);

                        tblayout.addView(tr1);


                        String  firstname = null, lastname = null,rname=null;




                        JSONObject arrayobj = null;

                        for (int i = 0; i < postarray.length(); i++) {
                            tr1 = new TableRow(getApplicationContext());

                            Userid= new TextView(getApplicationContext());
                            Firstname = new TextView(getApplicationContext());
                            Lastname = new TextView(getApplicationContext());

                            Relname = new TextView(getApplicationContext());



                            try {
                                arrayobj = postarray.getJSONObject(i);



                                Userid.setTextSize(10);
                                Userid.setAlpha(1);
                                Firstname.setTextSize(10);
                                Firstname.setAlpha(1);
                                Lastname.setTextSize(10);
                                Lastname.setAlpha(0.99f);

                                Relname.setTextSize(10);
                                Relname.setAlpha(0.99f);

                                Userid.setText(uid + "  ");
                                tr1.addView(Userid);
                                firstname = arrayobj.getString("FirstName");
                                Firstname.setText(firstname + "  ");
                                tr1.addView(Firstname);
                                lastname = arrayobj.getString("LastName");
                                Lastname.setText(lastname + "  ");
                                tr1.addView(Lastname);
                                rname = arrayobj.getString("NAMEOFRELATION");
                                Relname.setText(rname + "  ");
                                tr1.addView(Relname);


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }



                            tr1.setAlpha(1);


                            tblayout.addView(tr1);


                            tr1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent bridge = new Intent(getApplicationContext(), FamilyHealthSummary.class);
                                    bridge.putExtra("Userid", uid);
                                    startActivity(bridge);
                                }
                            });


                        }

                    }
                });
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }


    }

}
