package com.example.yaadvir.healthmate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class PatientList extends AppCompatActivity {



    TableLayout tblayout;
    TableRow tr1;
    TextView Userid,Firstname,Lastname,dob,gen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_list);

        Toast.makeText(getApplicationContext(), "PLEASE SELECT THE USER ID TO CHECK MEDICAL REPORT ", Toast.LENGTH_LONG).show();


        new MyTask().execute();
    }

    private class MyTask extends AsyncTask<Void, Void, Void> {



        @SuppressLint("WrongThread")
        @Override

        protected Void doInBackground(Void... params) {



            URL url = null;


            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/Patient");

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                final StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());
                final JSONObject obj = new JSONObject(response.toString());

                final JSONArray postarray = obj.getJSONArray("singleUser");
                runOnUiThread(new Runnable() {
                    @SuppressLint("ResourceAsColor")
                    @Override
                    public void run() {

                        tblayout = findViewById(R.id.tablayout10);

                        tr1 = new TableRow(getApplicationContext());

                        Userid = new TextView(getApplicationContext());
                        Userid.setText(" User_id ");
                        Userid.setTextSize(10);
                        Userid.setAlpha(1);
                        Userid.setTextColor(Color.BLACK);

                        tr1.addView(Userid);


                        Firstname = new TextView(getApplicationContext());
                        Firstname.setText(" FirstName ");
                        Firstname.setAlpha(1);
                        Firstname.setTextSize(10);
                        Firstname.setTextColor(Color.BLACK);

                        tr1.addView(Firstname);

                        Lastname = new TextView(getApplicationContext());
                        Lastname.setText(" LastName ");
                        Lastname.setAlpha(1);
                        Lastname.setTextSize(10);
                        Lastname.setTextColor(Color.BLACK);



                        tr1.addView(Lastname);

                        dob = new TextView(getApplicationContext());
                        dob.setText(" DateOfBirth ");
                        dob.setAlpha(1);
                        dob.setTextSize(10);
                        dob.setTextColor(Color.BLACK);



                        tr1.addView(dob);

                        gen = new TextView(getApplicationContext());
                        gen.setText(" Gender ");
                        gen.setAlpha(1);
                        gen.setTextSize(10);
                        gen.setTextColor(Color.BLACK);



                        tr1.addView(gen);

                        tblayout.addView(tr1);


                        String  firstname = null, lastname = null,Dob=null,Gen=null;

                        int user_id = 0;


                        JSONObject arrayobj = null;

                        for (int i = 0; i < postarray.length(); i++) {

                            tr1 = new TableRow(getApplicationContext());

                            Userid= new TextView(getApplicationContext());
                            Firstname = new TextView(getApplicationContext());
                            Lastname = new TextView(getApplicationContext());
                            dob = new TextView(getApplicationContext());
                            gen = new TextView(getApplicationContext());


                            try {
                                arrayobj = postarray.getJSONObject(i);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            try {
                                user_id = arrayobj.getInt("User_id");


                                Userid.setTextSize(10);
                                Userid.setAlpha(1);
                                Firstname.setTextSize(10);
                                Firstname.setAlpha(1);
                                Lastname.setTextSize(10);
                                Lastname.setAlpha(0.99f);
                                dob.setTextSize(10);
                                dob.setAlpha(0.99f);
                                gen.setTextSize(10);
                                gen.setAlpha(0.99f);

                                Userid.setText(user_id + "  ");
                                tr1.addView(Userid);
                                firstname = arrayobj.getString("FirstName");
                                Firstname.setText(firstname + "  ");
                                tr1.addView(Firstname);
                                lastname = arrayobj.getString("LastName");
                                Lastname.setText(lastname + "  ");
                                tr1.addView(Lastname);
                                Dob = arrayobj.getString("DateOfBirth");
                                dob.setText(Dob + "  ");
                                tr1.addView(dob);
                                Gen = arrayobj.getString("Gender");
                                gen.setText(Gen + "  ");
                                tr1.addView(gen);




                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                            tr1.setAlpha(1);


                            tblayout.addView(tr1);



                            final int finalUser_id = user_id;
                            tr1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent bridge = new Intent(getApplicationContext(), PatHealth.class);
                                    bridge.putExtra("Userid", finalUser_id);
                                    startActivity(bridge);
                                }
                            });



                        }

                    }
                });
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }


    }

}


