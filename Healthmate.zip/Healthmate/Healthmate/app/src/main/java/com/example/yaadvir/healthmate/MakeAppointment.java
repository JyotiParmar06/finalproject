package com.example.yaadvir.healthmate;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class MakeAppointment extends AppCompatActivity {


    EditText Appid,Apptime,Appdate,Pid,Did;
    Button nextPage9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_appointment);

        Appid = (EditText)findViewById(R.id.appid);
        Apptime = (EditText)findViewById(R.id.appdate);
        Appdate = (EditText)findViewById(R.id.apptime);
        Pid=(EditText)findViewById(R.id.pid);
        Did = (EditText)findViewById(R.id. did);

        nextPage9 = findViewById(R.id.nextPage9);
        nextPage9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                o1=Appid.getText().toString();
                o4=Apptime.getText().toString();
                o5=Appdate.getText().toString();
                o2=Pid.getText().toString();

                o3=Did.getText().toString();

                Intent bridge = new Intent(getApplicationContext(), PatientProfile.class);
                startActivity(bridge);
                new MyTask().execute();
            }
        });


    }

    String o1,o2,o3,o4,o5;
    private class MyTask extends AsyncTask<Void, Void, Void> {



        @Override
        protected Void doInBackground(Void... voids) {

            URL url = null;


            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/bookappointment&"+o1+"&"+o2+"&"+o3+"&"+o4+"&"+o5);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj =new JSONObject(response.toString());

//                o1=""+obj.getString("APPOINTMENT_ID");
//                o2=""+obj.getString("PATIENT_ID");
//                o3=""+obj.getString("DOCTOR_ID");
//                o4=""+obj.getString("APPOINTMENT_TIME");
//                o5=""+obj.getString("APPOINTMENT_DATE");
//



            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();




            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result){

//            Appid.setText(o1);
//            Pid.setText(o2);
//            Did.setText(o3);
//            Apptime.setText(o4);
//            Appdate.setText(o5);



            super.onPostExecute(result);
        }
    }



}



