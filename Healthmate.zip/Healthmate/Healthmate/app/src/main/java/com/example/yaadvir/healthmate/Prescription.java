package com.example.yaadvir.healthmate;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class Prescription extends AppCompatActivity {

    TableLayout tblayout;
    TableRow tr1;
    TextView Uid,Med,dose,timing;
    int uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription);


        new MyTask().execute();
    }

    private class MyTask extends AsyncTask<Void, Void, Void> {



        @SuppressLint("WrongThread")
        @Override

        protected Void doInBackground(Void... params) {



            URL url = null;


            User_id userID=User_id.getInstance();

            uid=userID.getId();
            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/prescription&"+uid);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                final StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());
                final JSONObject obj = new JSONObject(response.toString());

                final JSONArray postarray = obj.getJSONArray("Prescription");
                runOnUiThread(new Runnable() {
                    @SuppressLint("ResourceAsColor")
                    @Override
                    public void run() {

                        tblayout = findViewById(R.id.tablayout9);


                        tr1 = new TableRow(getApplicationContext());


                        Uid = new TextView(getApplicationContext());
                        Uid.setText(" USER_ID ");
                        Uid.setTextSize(20);
                        Uid.setAlpha(1);
                        Uid.setTextColor(Color.BLACK);

                        tr1.addView(Uid);


                        Med = new TextView(getApplicationContext());
                        Med.setText(" NAMEOFMEDICINE ");
                        Med.setAlpha(1);
                        Med.setTextSize(20);
                        Med.setTextColor(Color.BLACK);

                        tr1.addView(Med);

                        dose = new TextView(getApplicationContext());
                        dose.setText(" DOSE ");
                        dose.setAlpha(1);
                        dose.setTextSize(20);
                        dose.setTextColor(Color.BLACK);

                        tr1.addView(dose);

                        timing = new TextView(getApplicationContext());
                        timing.setText(" Appointment_Time ");
                        timing.setAlpha(1);
                        timing.setTextSize(20);
                        timing.setTextColor(Color.BLACK);

                        tr1.addView(timing);





                        tblayout.addView(tr1);


                        String  med = null, Dose = null, time=null;


                        JSONObject arrayobj = null;

                        for (int i = 0; i < postarray.length(); i++) {
                            tr1 = new TableRow(getApplicationContext());


                            Uid = new TextView(getApplicationContext());
                            Med = new TextView(getApplicationContext());
                            dose = new TextView(getApplicationContext());
                            timing = new TextView(getApplicationContext());




                            try {
                                arrayobj = postarray.getJSONObject(i);




                                Uid.setTextSize(20);
                                Uid.setAlpha(1);
                                Med.setTextSize(20);
                                Med.setAlpha(0.99f);
                                dose.setTextSize(20);
                                dose.setAlpha(0.99f);
                                timing.setTextSize(20);
                                timing.setAlpha(0.99f);



                                uid = arrayobj.getInt("USER_ID");
                                Uid.setText(uid + "  ");
                                tr1.addView(Uid);
                                med = arrayobj.getString("NAMEOFMEDICINE");
                                Med.setText(med + "  ");
                                tr1.addView(Med);
                                Dose = arrayobj.getString("DOSE");
                                dose.setText(Dose + "  ");
                                tr1.addView(dose);
                                time = arrayobj.getString("TIMING");
                                timing.setText(time + "  ");
                                tr1.addView(timing);



                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                            tr1.setAlpha(1);




                            tblayout.addView(tr1);




                        }

                    }
                });
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }


    }

}


