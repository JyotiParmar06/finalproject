 package com.example.yaadvir.healthmate;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

 public class Registration extends AppCompatActivity {
    EditText FN,LN,GEN,DOB,SPEC,TYPE,UID,PASS;
    Button nextPage16;
     String o1,o2,o3,o4,o5,o6,o7,o8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        FN = (EditText)findViewById(R.id.fname);
        LN = (EditText)findViewById(R.id.lname);
        GEN = (EditText)findViewById(R.id.gen);
        TYPE=(EditText)findViewById(R.id.usertype);
        DOB = (EditText)findViewById(R.id.  dob);
        SPEC = (EditText)findViewById(R.id.spec);
        UID = (EditText)findViewById(R.id.userid);
        PASS = (EditText)findViewById(R.id.pass);


        nextPage16 = findViewById(R.id.nextPage16);
        nextPage16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                o2=FN.getText().toString();
                o3=LN.getText().toString();
                o8=GEN.getText().toString();
                o7=TYPE.getText().toString();
                o6=DOB.getText().toString();
                o5=SPEC.getText().toString();
                o1=UID.getText().toString();
                o4=PASS.getText().toString();


                new MyTask().execute();
            }
        });




    }


    private class MyTask extends AsyncTask<Void, Void, Void> {



        @Override
        protected Void doInBackground(Void... voids) {

            URL url = null;


            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/Registration&"+o1+"&"+o2+"&"+o3+"&"+o4+"&"+o5+"&"+o6+"&"+o7+"&"+o8);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj =new JSONObject(response.toString());

//                o1=""+obj.getString("FirstName");
                //o2=""+obj.getString("LastName");
                //o3=""+obj.getString("Password");
                //o4=""+obj.getString("DateOfBirth");
                //o5=""+obj.getString("Gender");
               // o6=""+obj.getString("USER_TYPE");
                //o7=""+obj.getString("Specialization");
               // o8=""+obj.getInt("UserId");




            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();




            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result){
//
//            FN.setText(o1);
//            LN.setText(o2);
//            PASS.setText(o3);
//            DOB.setText(o4);
//            GEN.setText(o5);
//            SPEC.setText(o7);
//            UID.setText(o8);
//            TYPE.setText(o6);
//


            Intent bridge = new Intent(getApplicationContext(), Login.class);
            startActivity(bridge);

            super.onPostExecute(result);
        }
    }



}



