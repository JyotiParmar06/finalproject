package com.example.yaadvir.healthmate;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class AddFamilyMember extends AppCompatActivity {


    EditText Rname,uid1,uid2;
    Button nextPage23;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_family_member);
        nextPage23 = findViewById(R.id.nextPage23);
        Rname = (EditText)findViewById(R.id.editText8);
        uid1 = (EditText)findViewById(R.id.editText11);
        uid2 = (EditText)findViewById(R.id.editText9);

        nextPage23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                o1=Rname.getText().toString();
                o2=uid1.getText().toString();
                o3=uid2.getText().toString();
                new MyTask().execute();
            }
        });



    }

    String o1,o2,o3,o4;
    private class MyTask extends AsyncTask<Void, Void, Void> {



        @Override
        protected Void doInBackground(Void... voids) {

            URL url = null;


            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/RelationType&'"+o1+"'&'"+o2+"'&"+o3+"'");

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj =new JSONObject(response.toString());

//                o1=""+obj.getString("NAMEOFRELATION");
//                o2=""+obj.getString("USER_ID1");
//                o3=""+obj.getString("USER_ID2");

            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();




            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result){

            Rname.setText(o1);
            uid1.setText(o2);
            uid2.setText(o3);


            super.onPostExecute(result);
        }
    }



}






