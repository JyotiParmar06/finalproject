package com.example.yaadvir.healthmate;

public class User_id {

    private int id;
    private String in;
    public String getIn(){
        return in;
    }
    private String up;
    public void setIn(String in){
        this.in=in;
    }
    public void setUp(String up){
        this.up=up;
    }
    private static final User_id theid=new User_id();
    public static User_id getInstance(){
        return theid;
    }
    public int getId(){
        return id;
    }
    public void setId(int id){this.id=id;}

}
