package com.example.yaadvir.healthmate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class PatHealth extends AppCompatActivity {

    TableLayout tblayout;
    TableRow tr1;
    TextView Testname,Testresult;
    int uid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pat_health);


        new MyTask().execute();
    }

    private class MyTask extends AsyncTask<Void, Void, Void> {



        @SuppressLint("WrongThread")
        @Override

        protected Void doInBackground(Void... params) {



            URL url = null;

            Intent myNewIntent=getIntent();

            Integer User_Id=myNewIntent.getIntExtra("Userid",99);
            uid = User_Id;

            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/healthsummary&"+uid);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                final StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());
                final JSONObject obj = new JSONObject(response.toString());

                final JSONArray postarray = obj.getJSONArray("TESTS");
                runOnUiThread(new Runnable() {
                    @SuppressLint("ResourceAsColor")
                    @Override
                    public void run() {

                        tblayout = findViewById(R.id.tablayout50);

                        tr1 = new TableRow(getApplicationContext());


                        Testname = new TextView(getApplicationContext());
                        Testname.setText(" Test_Name ");
                        Testname.setTextSize(20);
                        Testname.setAlpha(1);
                        Testname.setTextColor(Color.BLACK);

                        tr1.addView(Testname);


                        Testresult = new TextView(getApplicationContext());
                        Testresult.setText(" TESTRESULT ");
                        Testresult.setAlpha(1);
                        Testresult.setTextSize(20);
                        Testresult.setTextColor(Color.BLACK);

                        tr1.addView(Testresult);




                        tblayout.addView(tr1);


                        String  tname = null, tresult = null;


                        JSONObject arrayobj = null;

                        for (int i = 0; i < postarray.length(); i++) {
                            tr1 = new TableRow(getApplicationContext());


                            Testresult = new TextView(getApplicationContext());
                            Testname = new TextView(getApplicationContext());




                            try {
                                arrayobj = postarray.getJSONObject(i);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            try {



                                Testname.setTextSize(20);
                                Testname.setAlpha(1);
                                Testresult.setTextSize(20);
                                Testresult.setAlpha(0.99f);


                                tname = arrayobj.getString("TESTNAME");
                                Testname.setText(tname + "  ");
                                tr1.addView(Testname);
                                tresult = arrayobj.getString("TESTRESULT");
                                Testresult.setText(tresult + "  ");
                                tr1.addView(Testresult);



                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                            tr1.setAlpha(1);


                            tblayout.addView(tr1);



                        }

                    }
                });
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }


    }

}

