package com.example.yaadvir.healthmate;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class DoctorProfile extends AppCompatActivity {



    TextView out2;
    int uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_profile);

        out2 =(TextView) findViewById(R.id.textView);
        new MyTask().execute();
    }

    private class MyTask extends AsyncTask<Void, Void, Void> {

        String o1,o2;
        @Override
        protected Void doInBackground(Void... params) {


            URL url = null;


            Integer UID;
            User_id user_id=User_id.getInstance();
            UID=user_id.getId();

            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/doctorprofile&" + UID);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println("The response is " + response.toString());
                JSONObject obj =new JSONObject(response.toString());

                o2=""+obj.getString("Firstname");
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {


            out2.setText(o2);

            super.onPostExecute(result);
        }
    }
    public void click1(View myView) {
        Intent myIntent = new Intent(this, PatientList.class);
        startActivity(myIntent);
    }
    public void click2(View myView) {
        Intent myIntent = new Intent(this, DoctorAppointment.class);
        startActivity(myIntent);
    }
    public void click3(View myView) {
        Intent myIntent = new Intent(this, DoctorInbox.class);
        startActivity(myIntent);
    }
    public void click4(View myView) {
        Intent myIntent = new Intent(this, Login.class);
        startActivity(myIntent);
    }
}
