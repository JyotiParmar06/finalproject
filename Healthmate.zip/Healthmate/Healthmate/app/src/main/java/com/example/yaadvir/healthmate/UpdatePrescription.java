package com.example.yaadvir.healthmate;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class UpdatePrescription extends AppCompatActivity {


    EditText TId,Pid,P_time;
    Button nextPage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_prescription);
        nextPage = findViewById(R.id.nextPage);
        TId = (EditText)findViewById(R.id.editText3);
        Pid = (EditText)findViewById(R.id.editText7);
        P_time = (EditText)findViewById(R.id.editText6);

        nextPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                o1=TId.getText().toString();
                o2=Pid.getText().toString();
                o3=P_time.getText().toString();


                Intent bridge = new Intent(getApplicationContext(), UpdateDetail.class);
                startActivity(bridge);
                new MyTask().execute();
            }
        });



    }

    String o1,o2,o3,o4;
    private class MyTask extends AsyncTask<Void, Void, Void> {



        @Override
        protected Void doInBackground(Void... voids) {

            URL url = null;


            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/Prescription&"+o1+"&"+o2+"&"+o3);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj =new JSONObject(response.toString());
//
//                o1=""+obj.getInt("TREATMENT_ID");
//                o2=""+obj.getInt("PRESCRIPTION_ID");
//                o3=""+obj.getInt("PRESCRIPTION_TIME");

            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();




            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result){

//            TId.setText(o1);
//            Pid.setText(o2);
//            P_time.setText(o3);


            super.onPostExecute(result);
        }
    }



}






