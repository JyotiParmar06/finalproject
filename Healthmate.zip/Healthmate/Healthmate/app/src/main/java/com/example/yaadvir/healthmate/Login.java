package com.example.yaadvir.healthmate;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class Login extends AppCompatActivity {
    EditText out1, out2;
    Button mypatprofile,mydocprofile;
    String o1;
    String o2;
    String userType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        out1 =(EditText) findViewById(R.id.editText);
        out2 =(EditText) findViewById(R.id.editText2);
        mypatprofile = findViewById(R.id.profile);

        mypatprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                o1=out1.getText().toString();
                o2=out2.getText().toString();

                System.out.println(o1);
                System.out.println(o2);
                new MyTask().execute();
            }
        });

        mydocprofile = findViewById(R.id.button3);
        mydocprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                o1=out1.getText().toString();
                o2=out2.getText().toString();

                System.out.println(o2);
                System.out.println(o1);
                new MyTask().execute();

            }
        });



    }




    private class MyTask extends AsyncTask<Void, Void, Void> {

        String o3;
        int o4;
        @Override
        protected Void doInBackground(Void... voids) {

            URL url = null;


            try {

                url = new URL("http://192.168.0.126:33051/Health/healthmate/main/userlogin&"+o1+"&"+o2);

                HttpURLConnection client = null;

                client = (HttpURLConnection) url.openConnection();

                client.setRequestMethod("GET");

                int responseCode = client.getResponseCode();

                System.out.println("\n Sending 'GET' request to URL : " + url);

                System.out.println("Response Code : " + responseCode);

                InputStreamReader myInput = new InputStreamReader(client.getInputStream());

                BufferedReader in = new BufferedReader(myInput);
                String inputLine;
                StringBuffer response = new StringBuffer();


                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                //print result
                System.out.println(response.toString());

                JSONObject obj =new JSONObject(response.toString());


               userType= obj.getString("USER_TYPE");
                o2=""+obj.getString("PASSWORD");
                o3=""+obj.getString("Firstname");
                o4=+obj.getInt("USER_ID");


                User_id userid=User_id.getInstance();
                userid.setId(o4);
                System.out.println(userid.getId());

                //uid=o1;
                // pw=o2;


            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result){

            out1.setText(o1);

            out2.setText(o2);


            super.onPostExecute(result);
            if(userType.equals("Doctor")) {

                Intent bridge = new Intent(getApplicationContext(), DoctorProfile.class);
                bridge.putExtra("user_id", o4);
                startActivity(bridge);
            }else{
                Intent bridge = new Intent(getApplicationContext(), PatientProfile.class);
                bridge.putExtra("user_id", o4);
                startActivity(bridge);

            }
        }
    }


    public void nextPage(View myView) {
        Intent myIntent = new Intent(this, Registration.class);

        startActivity(myIntent);
    }



}
